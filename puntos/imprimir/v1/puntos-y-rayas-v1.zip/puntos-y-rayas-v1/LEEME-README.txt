PUNTOS Y RAYAS: juego para imprimir (v1, 2026-10-17)

Lo que importa son las rayas entre los puntos. De 2 a 8 personas, adultos.
Reglas, video y juego en línea: https://hallucatrix.com/puntos/

IMPRIMIR EN CASA (carpeta casa/)
- cartas-carta.pdf o cartas-a4.pdf: 12 hojas, 9 cartas por hoja, al tamaño real (63 × 88 mm). Corta por las marcas.
  Imprime al 100 % (sin «ajustar a la página»), de preferencia en cartulina.
- reversos-carta.pdf o reversos-a4.pdf: una hoja de reversos. Imprímela al reverso de cada hoja de cartas
  (voltear por el lado largo), o sáltatela y usa fundas opacas.
- reglamento-carta.pdf: el reglamento, 4 hojas carta por los dos lados (voltear por el lado corto). Dobla y engrapa:
  queda un cuadernillo de 16 páginas, en español de un lado y en inglés del otro. En A4, imprime ajustando a la página.
- hoja-de-puntos-carta.pdf: dos hojas de puntos por hoja carta.

EN IMPRENTA (carpeta imprenta/)
- Pliegos de 33 × 48 cm con rebase y marcas de corte (18 cartas por pliego, 6 pliegos de frente y 1 de reverso),
  la nota para la imprenta (LEEME-imprenta.pdf) y cada pieza suelta en por-pieza/.

Un juego: 96 cartas numeradas, 4 Chispas (+1 de repuesto), 4 tarjetas de turno, Mercado, «Empiezas tú» y QR.
Para 5 a 8 personas, imprime dos juegos.

Licencia: CC BY-NC-SA 4.0 (mira LICENCIA-LICENSE.txt). Imprímelo, compártelo y adáptalo gratis; da crédito,
no lo vendas y comparte tus cambios con la misma licencia.

------------------------------------------------------------

DOTS & LINES: print-and-play game (v1, 2026-10-17)

The point is the lines between points. 2 to 8 players, adults.
Rules, video and online play: https://hallucatrix.com/puntos/

PRINT AT HOME (folder casa/)
- cartas-carta.pdf (US letter) or cartas-a4.pdf: 12 pages, 9 cards per page at real size (63 × 88 mm). Cut on the marks.
  Print at 100% (no "fit to page"), on card stock if you can.
- reversos-carta.pdf or reversos-a4.pdf: one page of card backs. Print it on the back of each card page
  (flip on the long edge), or skip it and use opaque sleeves.
- reglamento-carta.pdf: the rulebook, 4 letter sheets printed on both sides (flip on the short edge). Fold and staple:
  a 16-page booklet, Spanish from one side and English from the other. On A4, print with "fit to page".
- hoja-de-puntos-carta.pdf: score sheets, two per letter page.

AT A PRINT SHOP (folder imprenta/)
- 33 × 48 cm press sheets with bleed and crop marks (18 cards per sheet, 6 front sheets and 1 back sheet),
  the printer's note in Spanish (LEEME-imprenta.pdf) and every piece on its own in por-pieza/.

One set: 96 numbered cards, 4 Sparks (+1 spare), 4 turn cards, Market, "You start" and QR card.
For 5 to 8 players, print two sets.

Licence: CC BY-NC-SA 4.0 (see LICENCIA-LICENSE.txt). Print, share and adapt it for free; give credit,
don't sell it, and share your changes under the same licence.
